
Mini-RISC FreeRTOS
==================

Template de projet C utilisant le système d'exploitation temps réel
[FreeRTOS](https://www.freertos.org/) sur le Mini-RISC via l'émulateur Harvey.

