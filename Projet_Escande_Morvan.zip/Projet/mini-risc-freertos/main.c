#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include "harvey_platform.h"
#include "minirisc.h"
#include "uart.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "xprintf.h"
#include "queue.h"


#define SCREEN_WIDTH  24
#define SCREEN_HEIGHT 24

//création du mutex sur le tableau
static SemaphoreHandle_t array_mutex = NULL;

//déclaration globale du terrain
int* terrain; //création du tableau terrain
int fin = 0; //signale la fin à tous les processus
static QueueHandle_t command_queue; //la queue à une longueur 1 car on ne veut pas prendre plus de 1 commande par step
//initialisation de variables additionelles
int command = 2;
int score  = 0;

//partie vidéo
static uint32_t frame_buffer[480 * 480];
volatile uint32_t color = 0x00ff0000;



uint32_t make_color(uint8_t red, uint8_t green, uint8_t blue) {
    return ((uint32_t)red << 16) | ((uint32_t)green << 8) | (uint32_t)blue;
}

void init_video()
{
	memset(frame_buffer, 0, sizeof(frame_buffer)); // clear frame buffer to black
	VIDEO->WIDTH  = 480;
	VIDEO->HEIGHT = 480;
	VIDEO->DMA_ADDR = frame_buffer;
	VIDEO->CR = VIDEO_CR_IE | VIDEO_CR_EN;
}

void draw_square(int x, int y, int width, uint32_t color)
{
	if (x >= SCREEN_WIDTH || y >= SCREEN_HEIGHT) {
		return;
	}
	int i, j;
	int x_start = x < 0 ? 0 : x;
	int y_start = y < 0 ? 0 : y;
	int x_end = x + width;
	int y_end = y + width;
	if (x_end > SCREEN_WIDTH) {
		x_end = SCREEN_WIDTH;
	}
	if (y_end > SCREEN_HEIGHT) {
		y_end = SCREEN_HEIGHT;
	}
	for (j = y_start; j < y_end; j++) {
		for (i = x_start; i < x_end; i++) {
			frame_buffer[j*SCREEN_WIDTH + i] = color;
		}
	}
}


void video(void* arg)
{
	(void)arg;
	while (1) //(!fin)
	{
		while(VIDEO->SR != 0)
		{}
		//début du rafraichissement
		VIDEO->SR = 0;
		for (int i = 0; i < SCREEN_WIDTH*SCREEN_HEIGHT; i++)
		{
			xSemaphoreTake(array_mutex, portMAX_DELAY);
			//DEBUT SECTION CRITIQUE
			if (terrain[i] > 0)
			{
				for (int x = 0; x < 20; x++)
				{
					for (int y = 0; y < 20; y++)
					{
						VIDEO->DMA_ADDR[((i/24)*20 + x) *VIDEO->WIDTH + y + (i%24)*20] = make_color(0,255,0);
					}
				}

			}
			else if (terrain[i] == -1)
			{
				for (int x = 0; x < 20; x++)
				{
					for (int y = 0; y < 20; y++)
					{
						VIDEO->DMA_ADDR[((i/24)*20 + x) *VIDEO->WIDTH + y + (i%24)*20] = make_color(255,0,0);
					}
				}
			}
			else
			{				
				for (int x = 0; x < 20; x++)
				{
					for (int y = 0; y < 20; y++)
					{
						VIDEO->DMA_ADDR[((i/24)*20 + x) *VIDEO->WIDTH + y + (i%24)*20] = make_color(0,0,0);
					}
				}
			}
			xSemaphoreGive(array_mutex);
		}

	}
	free((uint32_t*)VIDEO->DMA_ADDR);


	//return 0;
}

//fin de partie vidéo
int vx = 1;
int vy = 0;

void keyboard_interrupt_handler()
{
	BaseType_t xHigherPriorityTaskWoken = pdFALSE;
	uint32_t kdata;
	while (KEYBOARD->SR & KEYBOARD_SR_FIFO_NOT_EMPTY) {
		kdata = KEYBOARD->DATA;
		if (kdata & KEYBOARD_DATA_PRESSED) {
			//xprintf("key code: %d\n", KEYBOARD_KEY_CODE(kdata));
			switch (KEYBOARD_KEY_CODE(kdata)) {
				case 27: // echap
					xprintf("Votre score est %d.\n", score);
					minirisc_halt();
					break;
				case 80:
					//left arrow
					if (vx != 1)
					{
						vx = -1;
						vy = 0;
						command = 4;
					}
					break;
				case 82:
					//up arrow
					if(vy!=1)
					{
						vx = 0;
						vy = -1;
						command = 3;
					}
					break;
				case 79:
					//right arrow
					if (vx != -1)
					{
						vx = 1;
						vy = 0;
						command = 2;
					}
					break;
				case 81:
					//down arrow
					if (vy != -1)
					{
						vx = 0;
						vy = 1;
						command = 1;
					}
					break;
			}
			
			xQueueSendFromISR(command_queue, &command, &xHigherPriorityTaskWoken);
		}
	}
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}








void logique(void * arg)
{
	(void)arg;
	

	
	/*Le terrain est géré de la façon suivante :
	-Chaque case du tableau terrain représente une case du terrain
	-l'accés à une case du tableau se fait avec la formule tableau[x][y] = tableau[x*SCREEN_WIDTH + y]
	-Cette case ne peut prendre que certaines valeurs :
		- 0 si la case est vie, elle est donc libre et le serpent peut y avancer
		- -1 si la case contient une pomme
		- 1, 2, 3, 4 ou 5 si la case contient une des écailles du serpent
	- la valeur d'une des écailles indique la direction de la prochaine écaille du serpent
	- ainsi, si le serpent avance, on fait avancer le pointeur de la queue vers l'écaille suivante et on supprime la dernière écaille
	
	Significatation des valeurs des écailles :
	.1 la prochaine écaille est en bas
	.2 la prochaine écaille est à droite
	.3 la prochaine écaille est en haut
	.4 la prochaine écaille est à gauche
	.5 indique que cette case est la tête du serpent et qu'on ne connait pas encore la prochaine écaille
	*/


	//initialisation des 3 premières écailles
	int x = SCREEN_WIDTH/2;
	int y = SCREEN_HEIGHT/2;
	int py = y;


	xSemaphoreTake(array_mutex, portMAX_DELAY);
	//DEBUT SECTION CRITIQUE
	terrain[x*SCREEN_WIDTH + y] = 5;
	terrain[x*SCREEN_WIDTH + y-1] = 2;
	terrain[x*SCREEN_WIDTH + y-2] = 2;


	//initialisation des pointeurs de tête et de queue
	int pQueue = x*SCREEN_WIDTH + y-2;
	int pHead = x*SCREEN_WIDTH + y;
	int ppHead = pHead;

	//initialisation de la pomme, elle est traditionellement en face du serpent
	// /!\ Cette ligne peut générer des erreurs pour de petits écrans.
	terrain[x*SCREEN_WIDTH + 3*SCREEN_WIDTH/4] = -1;
	//FIN SECTION CRITIQUE
	xSemaphoreGive(array_mutex);
	
	while (1) { //!fin) {
		//on attend l'interrupt du timer
		//vTaskDelay(MS2TICKS(500));
		vTaskDelay(10);

		//lire l'instruction dans la pile
		if (uxQueueMessagesWaiting(command_queue) > 0)
		{
			while(xQueueReceive(command_queue, &command, portMAX_DELAY) == pdFALSE) {printf("Not reading anything from the queue, but queue not empty, trying again...\n");}
			//la commande est donc maintenant dans la variable commande
		}
		//si pas d'instruction, l'instruction est la même que la précédente (ne pas reset la valeur)

		//dans tous les cas, faire avancer le pointeur de tête et remplir la case de la tête précédente avec la bonne direction

		xSemaphoreTake(array_mutex, portMAX_DELAY);
		terrain[pHead] = command; //remplir la case, SECTION CRITIQUE
		ppHead = pHead;
		//update le pointeur
		switch (command)
		{
			case 1:
				pHead += SCREEN_WIDTH; //les ordonnées sont descendantes
				break;
			case 2:
				pHead += 1;
				break;
			case 3:
				pHead -= SCREEN_WIDTH;
				break;
			case 4:
				pHead -= 1;
				break;
		}
		

		//signaler toute collision en mettant fin au jeu (par exemple en mettant la première case du tableau à -2)
		// si x > screen width ou < 0, y > screen heigth ou < 0...

		x = pHead/SCREEN_WIDTH;
		y = pHead%SCREEN_WIDTH;
		py = ppHead%SCREEN_WIDTH;


		fin = !((x >= 0) && (x < SCREEN_HEIGHT) && (abs(py - y) < 10) && (terrain[pHead] <= 0));
		//xprintf(" x : %d, y : %d\n", x, y);
		
		//si pas de collision, vérifier si une pomme est sur la case
		if (!fin)
		{
			if (terrain[pHead] == -1) //si on a une pomme, pas section critique, on ne fait que lire
			{
				//xprintf("Pomme\n");
				score += 1;//on augmente le score

				x = rand()%SCREEN_WIDTH;
				y = rand()%SCREEN_HEIGHT;

				while (terrain[x*SCREEN_WIDTH + y] > 0) //si on tombe sur une pomme ou le serpent, pas de section critique, on ne fait que lire
				{
					//on regénére une nouvelle position jusqu'a tomber sur une case libre
					x = rand()%SCREEN_WIDTH;
					y = rand()%SCREEN_HEIGHT;
				}
				terrain[x*SCREEN_WIDTH + y] = -1;

			}
			//si pas de pomme, modifier le pointeur de queue
			else
			{
				x = terrain[pQueue]; //j'utilise x comme variable temporaire vu qu'elle existe...
				terrain[pQueue] = 0; //SECTION CRITIQUE
				//xprintf("Je bouge %d\n",terrain[pQueue]);
				switch (x) //on change le pointeur de queue
				{
					case 1:
						pQueue += SCREEN_WIDTH; //les ordonnées sont descendantes
						break;
					case 2:
						pQueue += 1; //on rappel que le tableau est en réalité à une dimension
						break;
					case 3:
						pQueue -= SCREEN_WIDTH;
						break;
					case 4:
						pQueue -= 1;
						break;
				}
				

			}
		}
		else
		{
			xprintf("Votre score est %d.\n", score);
			minirisc_halt();
		}
		terrain[pHead] = 5;
		VIDEO->SR = 1;
		xSemaphoreGive(array_mutex);
		
	}

	//return 0;
}


int main()
{
	//configuration du timer, toutes les 0.5s
	TIMER->ARR = 500;

	TIMER->CR |= TIMER_CR_EN | TIMER_CR_IE;
	KEYBOARD->CR |= KEYBOARD_CR_IE;

	minirisc_enable_interrupt(TIMER_INTERRUPT | KEYBOARD_INTERRUPT);

	minirisc_enable_global_interrupts();

	init_uart();
	array_mutex = xSemaphoreCreateMutex();
	terrain = malloc(sizeof(int)*SCREEN_WIDTH*SCREEN_HEIGHT);
	command_queue = xQueueCreate(16, sizeof(int));
	init_video();

	xTaskCreate(logique, "logique", 4096, NULL, 1, NULL);
	xTaskCreate(video,  "video",  4096, NULL, 1, NULL);
	vTaskStartScheduler();

	return 0;
}

